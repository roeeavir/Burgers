
public class BonusException extends Exception {

	//An exception class - In case of a high owner bonus.
	public BonusException() {
		super("!! Owner bonus is too high !!");
	}
}
