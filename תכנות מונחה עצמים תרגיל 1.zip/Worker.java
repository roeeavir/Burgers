
public class Worker extends Person{
	
	//Variables
	private int salary;
	
	//Constractor
	public Worker(int salary) {
		super();
		setSalary(salary);
	}
	
	//Getters & setters
	
	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;	
	}
	
	//toString
	@Override
	public String toString() {
		return "Worker : " + getName() + ", " + getSalary();
	}
}
