
public class Manager extends Worker {
	
	//Variables
	private int bonus;
	
	//Constructor
	public Manager(int salary,int bonus) {
		super(salary);
		this.bonus = bonus;
	}

	//Getters & setters
	
	public int getBonus() {
		return bonus;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}

	//toString
	@Override
	public String toString() {
		return "Manager : " + getName() + ", " + getSalary() + " + " + getBonus();
	}
}
