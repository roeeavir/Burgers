
import java.util.ArrayList;
import java.util.Scanner;

/*Name: Roee Aviran
ID: 316492644 */

public class HW1_RoeeAviran {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);//Input scanner.
		ArrayList list = new ArrayList();//The whole list of owners, managers and workers.
		char type;
		int i = 0;//Index number.
		
		//A loop to keep adding employees as long as the user wants.
		do {
			type = pickAType(in);
			insertIntoList(in, list, type);
			if ((type == 'O'|| type == 'o') && !(checkBonus(((Owner)list.get(i)).getBonus()))) {
				System.out.println("\nProgram ends now...");
				System.exit(0);//Will end the program in case of bonus exception.
			}
			i++;
		} while (type != 'f' && type != 'F');
		
		System.out.println("The list content:\n");
		printList(list);//Printing the list of employees.
		
		//using the method that prints the costs of all bonuses 
		System.out.println("Cost of all bonuses: " + costOfAllBonuses(list) + "\n");
		
		//A loop for the user to check each group of employees total costs, as many times as the user wants.
		do {
			System.out.println("Please type a character to get total cost by type:");
			type = pickAType(in);
			if ((type != 'f' && type != 'F') && (type == 'W'|| type == 'w')
					|| type == 'M'|| type == 'm' || type == 'O'|| type == 'o') {
				System.out.println(costByType(in, list, type));
			}
		} while (type != 'f' && type != 'F');
		
		
		int first, second;
		//A loop for comparing any two employees, as many times as the user wants.
		do {
			System.out.println("Please enter the first index in the list (-1 to finish):");
			first = getIndexes(in, list.size());
			if (first == -1) {
				break;
			}
			System.out.println("Please enter the second index in the list: ");
			second = getIndexes(in, list.size());
			if (compare(list, first, second)) {
				System.out.println("EQUALS!");
			}else {
				System.out.println("NOT EQUALS!");
			}
		} while (first != -1);
		
		System.out.println("Program ends now...");
		
		in.close();
	}
	
	// A method for inputing the first character for the worker from the user.
	public static char pickAType(Scanner in) {
		
		char type;
		System.out.println("[M/m], [W/w], [O/o]. [F/f] to finish:");
		type = in.next().charAt(0);
		return type;
		
	}
	
	//A method for inserting workers into a list.
	public static void insertIntoList(Scanner in, ArrayList list, char type) {
		int salary = 0;
		String name = null;
		
		if ((type != 'f' && type != 'F') && (type == 'W'|| type == 'w')
				|| type == 'M'|| type == 'm' || type == 'O'|| type == 'o') {
			name = nameInfo(in);
			in.nextLine();
			salary = salaryInfo(in);
			//A loop for repeating the users salary input in case of a bad salary input.
			while (salary <= -1) {
				System.out.println("Try again!");
				salary = salaryInfo(in);
			}
			
			//Choosing between the 3 types of employees.
			if(type == 'W'|| type == 'w') {
				creatWorker(in, name, salary, list);
			}
			else if (type == 'M'|| type == 'm') {
				creatManager(in ,name, salary, list);
			}
			else if(type == 'O'|| type == 'o') {
				creatOwner(in ,name, salary, list);
			}
			else {
				System.out.println("Wrong input, please try again!");
			}
		}
	}
	
	//A method for inserting the right variables into the owners constructor.
	public static void creatOwner(Scanner in, String name, int salary, ArrayList list) {
		System.out.println("Please enter bonus: ");
		int bonus = in.nextInt();
		Owner owner = new Owner(salary, bonus);
		owner.setName(name);
		
		list.add(owner);
	}
	
	//A method for inserting the right variables into the managers constructor.
	public static void creatManager(Scanner in, String name, int salary, ArrayList list) {
		System.out.println("Please enter bonus: ");
		int bonus = in.nextInt();
		Manager manager = new Manager(salary, bonus);
		manager.setName(name);
		
		list.add(manager);
	}
	
	//A method for inserting the right variables into the workers constructor.
	public static void creatWorker(Scanner in, String name, int salary, ArrayList list) {
		Worker worker = new Worker(salary);
		worker.setName(name);
		
		list.add(worker);
	}
	
	public static String nameInfo(Scanner in) {//A method for setting the name.
		System.out.println("Please enter full name: ");
		String name = in.next();
		
		return name;
	}
	
	//A method for setting the salary and to check if it is indeed and integer.
	public static int salaryInfo(Scanner in) {
		System.out.println("Please enter salary: ");
		int salary = 0;
		String stringSalary = in.nextLine();
		salary = checkSalary(stringSalary);
		return salary;
	}
	
	//A method for checking if the salary is indeed an integer and if the salary is o and above.
	public static int checkSalary(String stringSalary) {
		int salary = 0;
	try {
		salary = Integer.parseInt(stringSalary);
	} 
	catch (NumberFormatException e) {
		System.out.println("Invalid type for salary, integer is needed!");
		return -1;//Returning a negative value to sign that there is a bad input.
	}
	try {
		if (salary < 0) {
			throw new NumberFormatException();
		}
	}
	catch (NumberFormatException e) {
		System.out.println("Salary must be at least 0!");
		return -1;//Returning a negative value to sign that there is a bad input.
	}
	
	return salary;
	}
	
	//A method to keep in check the owners bonus.
	public static boolean checkBonus(int bonus) {
		try {
			if (bonus > 10000) {
				
				throw new BonusException();
			}
			
			return true;
		} 
		catch (Exception e) {
			
			System.out.println(e.getMessage());
			return false;
		}
	}
	
	//A method that sums up all the bonuses of all the employees.
	public static int costOfAllBonuses(ArrayList list) {
		int sum = 0;
		for (int i = 0; i < list.size(); i++) {
			
			if (list.get(i) instanceof Manager ) {
				sum += ((Manager)list.get(i)).getBonus();
				
			}
			else if(list.get(i) instanceof Owner) {
				sum += ((Owner)list.get(i)).getBonus();
			}
		}
		return sum;	
	}
	
	//A method that sums up all the costs of each employee type group.
	public static int costByType(Scanner in , ArrayList list, char type) {
		int cost = 0;
		if (type == 'W'|| type == 'w') {
			
			for (int i = 0; i < list.size(); i++) {
				
				if (list.get(i) instanceof Worker && !( list.get(i) instanceof Manager )
						
						&& !( list.get(i) instanceof Owner)) {
					cost += ((Worker)list.get(i)).getSalary();
				}
				System.out.print("cost = ");
			}
			
			return cost;
		}
		else if (type == 'M'|| type == 'm') {
			for (int i = 0; i < list.size(); i++) {
				
				if (list.get(i) instanceof Manager && !( list.get(i) instanceof Owner)) {
					
					cost += ((Manager)list.get(i)).getSalary() + ((Manager)list.get(i)).getBonus();
				}
				System.out.print("cost = ");
			}
			
			return cost;
		}
		else if (type == 'O'|| type == 'o') {
			
			for (int i = 0; i < list.size(); i++) {
				
				if (list.get(i) instanceof Owner) {
					
					cost += ((Owner)list.get(i)).getBonus() + ((Owner)list.get(i)).getSalary() + Owner.BASE;
				}
				System.out.print("cost = ");
			}
			
			return cost;
		} 
		System.out.println("Wrong input, please try again!");
		return 0;
	}
	
	//A method for comparing workers from each type by their total salary (salary + bonus + base).
	public static boolean compare(ArrayList list, int first, int second) {
		
		return list.get(first).equals(list.get(second));
	}
	
	//A method for getting the indexes (arraylist) for comparison between two employees.
	public static int getIndexes(Scanner in, int size) {
		int num;
		num = in.nextInt();
		
		if ((num < 0 || num > size) && !(num == -1)) {
			
			System.out.println("Index is too high or too low!");
		}
		return num;
	}
	
	//A method for printing the list of all employees.
	public static void printList(ArrayList list) {
		
		for (int i = 0; i < list.size(); i++) {
			
			System.out.println(list.get(i));
		}
		System.out.println();
	}

}
