
public class Owner extends Manager {
	//Variables
	public static final int BASE = 20_000; 
	
	//Constructor
	public Owner(int salary, int bonus) {
		super(salary, bonus);
		
	}


	//toString
	@Override
	public String toString() {
		return "Owner : " + getName() + ", " + getSalary() + " + " + getBonus() + " + " + BASE; 
				
	}
	
}
